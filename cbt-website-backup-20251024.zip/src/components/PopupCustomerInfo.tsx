"use client";
import { useState, useMemo } from "react";
import type { AddressPayload } from "./types";

type Props = {
  payload: AddressPayload;
  onBack: () => void; // go back to Panel 2
  onSubmit?: (args: { name: string; phone: string }) => void; // optional hook
};

export default function PopupCustomerInfo({ payload, onBack, onSubmit }: Props) {

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [isCreatingJob, setIsCreatingJob] = useState(false);

  // basic validation
  const isValidName = useMemo(() => name.trim().length >= 2, [name]);
  const isValidPhone = useMemo(() => {
    const p = phone.replace(/[^\d+]/g, "").trim();
    return p.length >= 7; // lightweight check; adjust as you like
  }, [phone]);

  const canSubmit = isValidName && isValidPhone;

  const requestTow = async () => {
    if (!canSubmit || isCreatingJob) return;

    setIsCreatingJob(true);

    try {
      // Create job first
      const jobResponse = await fetch("/api/create-job", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          service: payload.service,
          pickup: payload.pickup.address,
          dropoff: payload.isTowing ? payload.dropoff?.address : undefined,
          vehicle: `${payload.vehicle.year} ${payload.vehicle.make} ${payload.vehicle.model} • ${payload.vehicle.color}`,
          customer_name: name,
          customer_phone: phone,
          amountQuoted: payload.estimatedQuote || 0,
        }),
      });

      if (!jobResponse.ok) {
        throw new Error(`Failed to create job: ${jobResponse.status}`);
      }

      const jobData = await jobResponse.json();
      const jobId = jobData.jobId;

      // Optional external hook
      onSubmit?.({ name, phone });

      // Create Square Payment Link and redirect
      const paymentLinkResponse = await fetch("/api/create-square-payment-link", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          amount: payload.estimatedQuote || 0,
          jobId: jobId,
          service: payload.service,
          customer_name: name,
          customer_phone: phone,
          pickup_address: payload.pickup.address, // Pass pickup address for pre-filling
        }),
      });

      if (!paymentLinkResponse.ok) {
        throw new Error(`Failed to create payment link: ${paymentLinkResponse.status}`);
      }

      const paymentLinkData = await paymentLinkResponse.json();
      
      // Redirect to Square Payment Link
      window.location.href = paymentLinkData.paymentLinkUrl;
    } catch (error) {
      console.error("Error creating job or redirecting to Square:", error);
      alert("There was an error processing your request. Please try again or call us directly.");
    } finally {
      setIsCreatingJob(false);
    }
  };

  return (
    <div className="w-full h-full flex flex-col gap-4">
      {/* Header + Back */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold bg-white/90 text-[#1e1e4a] hover:bg-white"
          aria-label="Go back to address selection"
          title="Back"
        >
          ← Back
        </button>

        <div className="text-base sm:text-lg font-bold text-white">
          Customer Info
        </div>

        {/* spacer to balance layout */}
        <div className="w-[72px]" />
      </div>

      {/* Quick summary (optional context) */}
      <div className="rounded-xl border-2 border-[#1e1e4a] bg-white px-4 py-3 text-sm text-[#1e1e4a]">
        <div><b>Service:</b> {payload.service}</div>
        <div><b>Pickup:</b> {payload.pickup.address}</div>
        {payload.isTowing && payload.dropoff?.address && (
          <div><b>Drop-off:</b> {payload.dropoff.address}</div>
        )}
        {payload.distanceMilesRounded != null && (
          <div><b>Distance:</b> ~{payload.distanceMilesRounded} mi</div>
        )}
        <div><b>Estimate:</b> ${payload.estimatedQuote}</div>
      </div>

      {/* Form fields */}
      <div className="flex-1 rounded-xl border border-white/20 bg-white/70 p-4">
        <div className="grid grid-cols-1 gap-4">
          <div className="flex flex-col gap-1">
            <label htmlFor="customerName" className="text-sm font-semibold text-[#1e1e4a]">
              What is your name?
            </label>
            <input
              id="customerName"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 rounded-xl border-2 border-[#1e1e4a] bg-white px-4 text-base focus:outline-none focus:ring-4 focus:ring-[#1e1e4a]/30 focus:border-[#1e1e4a]"
              placeholder="Full name"
              autoComplete="name"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label htmlFor="customerPhone" className="text-sm font-semibold text-[#1e1e4a]">
              Phone number
            </label>
            <input
              id="customerPhone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="h-12 rounded-xl border-2 border-[#1e1e4a] bg-white px-4 text-base focus:outline-none focus:ring-4 focus:ring-[#1e1e4a]/30 focus:border-[#1e1e4a]"
              placeholder="(555) 123-4567"
              autoComplete="tel"
            />
          </div>
        </div>
      </div>

      {/* Payment Expectation Message with Trust Indicators */}
      <div className="mb-4 space-y-3">
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
          <div className="flex items-start gap-2">
            <svg className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd"/>
            </svg>
            <div className="text-xs text-blue-800">
              <p className="font-bold">Next: Quick & Secure Payment</p>
              <p>You&apos;ll be redirected to our secure Square checkout. Your info will be pre-filled for faster checkout!</p>
            </div>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="flex items-center justify-center gap-3 text-xs text-gray-600">
          <div className="flex items-center gap-1">
            <svg className="w-4 h-4 text-green-600" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"/>
            </svg>
            <span className="font-semibold">256-bit SSL</span>
          </div>
          <span className="text-gray-300">•</span>
          <div className="flex items-center gap-1">
            <svg className="w-4 h-4 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
              <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd"/>
            </svg>
            <span>PCI Compliant</span>
          </div>
          <span className="text-gray-300">•</span>
          <div className="flex items-center gap-1">
            <span className="font-bold text-blue-600">Square</span>
            <span>Secure</span>
          </div>
        </div>
      </div>

      {/* Submit */}
      <div className="flex justify-end">
        <button
          type="button"
          onClick={requestTow}
          disabled={!canSubmit || isCreatingJob}
          className="rounded-xl px-6 py-3 font-semibold shadow-none hover:shadow-none focus:shadow-none focus:outline-none focus:ring-0 border border-transparent bg-[#ffba42] text-white hover:bg-[#e6a739] transition disabled:opacity-50 disabled:cursor-not-allowed"

          title={isCreatingJob ? "Creating job..." : "Request Tow"}
        >
          {isCreatingJob ? "Creating Job..." : "Request Tow →"}
        </button>
      </div>
    </div>
  );
}
