"use client";
import { RefObject, useEffect, useMemo, useState } from "react";
import { YEARS, MAKES, MODELS_BY_MAKE, COLORS } from "../data/vehicleOptions";

type Props = {
  isTowing: boolean;
  choice: string;
  address: string;
  onAddressChange: (v: string) => void;
  pickupConfirmed: boolean;
  confirmPickupIfManual: () => void;
  resetPickup: () => void;
  dropoff: string;
  setDropoff: (v: string) => void;
  dropoffConfirmed: boolean;
  confirmDropoffIfManual: () => void;
  resetDropoff: () => void;
  distanceMilesRounded: number | null;
  inputRefPickup: RefObject<HTMLInputElement | null>;
  inputRefDropoff: RefObject<HTMLInputElement | null>;
  initAutocompleteFor: (which: "pickup" | "dropoff") => void;
  isLocating: boolean;
  shareCurrentLocation: () => void;
  dropPinPlusCode: () => void;
  geoError: string | null;
  pricingError: string | null;
  year: string; setYear: (v: string) => void;
  make: string; setMake: (v: string) => void;
  model: string; setModel: (v: string) => void;
  color: string; setColor: (v: string) => void;
};

export default function LocationStep(props: Props) {
  const {
    isTowing, choice,
    address, onAddressChange, pickupConfirmed, confirmPickupIfManual, resetPickup,
    dropoff, setDropoff, dropoffConfirmed, confirmDropoffIfManual, resetDropoff,
    distanceMilesRounded,
    inputRefPickup, inputRefDropoff, initAutocompleteFor,
    isLocating, shareCurrentLocation, dropPinPlusCode,
    geoError,
    pricingError,
    year, setYear, make, setMake, model, setModel, color, setColor,
  } = props;

  const [customMake, setCustomMake] = useState("");
  const [isCustomMake, setIsCustomMake] = useState(false);
  const [customModel, setCustomModel] = useState("");
  const [isCustomModel, setIsCustomModel] = useState(false);

  // --- Robust model list for selected make (case/space tolerant)
  const modelsForMake = useMemo(() => {
    const m = (make || "").trim();
    if (!m || isCustomMake) return [];
    // direct match first
    if (MODELS_BY_MAKE[m]) return MODELS_BY_MAKE[m];

    // try case-insensitive, space-insensitive
    const keyNorm = m.toLowerCase().replace(/\s+/g, "");
    for (const [k, v] of Object.entries(MODELS_BY_MAKE)) {
      const kn = k.toLowerCase().replace(/\s+/g, "");
      if (kn === keyNorm) return v;
    }
    return [];
  }, [make, isCustomMake]);

  // Reset model whenever make changes
  useEffect(() => {
    setModel("");
    setCustomModel("");
    setIsCustomModel(false);
  }, [make, setModel]);

  return (
    <div className="flex-1 p-8 flex flex-col items-center justify-start gap-6 transition-all duration-200" style={{ backgroundColor: "#f0f8ff" }}>
      {/* Selected service (kept) */}
      <div className="text-lg sm:text-xl font-bold text-[#1e1e4a] text-center">
        Selected service:&nbsp;<span className="font-extrabold">{choice}</span>
      </div>

      {/* PICKUP / VEHICLE LOCATION */}
      <div className="w-full max-w-2xl">
        {!pickupConfirmed ? (
          <>
            {/* Small, left-aligned label (matches drop-off style) */}
            <div className="mb-2 text-base font-semibold text-[#1e1e4a]">
              {isTowing ? "What is pick up location" : "What is your vehicle location"}
            </div>

            <input
              id="pickupAddress"
              ref={inputRefPickup}
              value={address}
              onChange={(e) => onAddressChange(e.target.value)}
              onFocus={() => initAutocompleteFor("pickup")}
              onKeyDown={(e) => e.key === "Enter" && confirmPickupIfManual()}
              type="text"
              placeholder={isTowing ? "Enter pickup address (street, city, ZIP)…" : "Enter vehicle location (street, city, ZIP)…"}
              className="w-full h-16 rounded-2xl border-2 border-[#1e1e4a] bg-white px-6 text-xl focus:outline-none focus:ring-4 focus:ring-[#1e1e4a]/30 focus:border-[#1e1e4a] placeholder:text-[#1e1e4a]/40"
              autoComplete="off"
            />


            <div className="mt-3 grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={shareCurrentLocation}
                className="rounded-xl p-0 text-sm font-semibold shadow-lg border-2 border-blue-200 bg-gradient-to-b from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 active:shadow-md transition-all duration-200 flex items-center justify-center w-36 h-14"
                disabled={isLocating}
                title="Use GPS and fill the address automatically"
              >
                <div className="flex items-center gap-2 pr-2">
                  <svg className="w-6 h-6 text-red-500" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                  </svg>
                  {isLocating ? (
                    "Locating…"
                  ) : (
                    <span className="text-left text-xs">
                      <div>Share my current</div>
                      <div>location</div>
                    </span>
                  )}
                </div>
              </button>
              <button
                type="button"
                onClick={dropPinPlusCode}
                className="rounded-xl p-0 text-sm font-semibold shadow-lg border-2 border-blue-200 bg-gradient-to-b from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 active:shadow-md transition-all duration-200 flex items-center justify-center w-36 h-14"
                disabled={isLocating}
                title="Open Google Maps with a pin and put your Plus Code in the box"
              >
                <div className="flex items-center gap-2 pr-2">
                  <svg className="w-6 h-6" viewBox="0 0 24 24">
                    <defs>
                      <linearGradient id="pinGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" style={{stopColor:'#ff4444', stopOpacity:1}} />
                        <stop offset="100%" style={{stopColor:'#cc0000', stopOpacity:1}} />
                      </linearGradient>
                      <linearGradient id="shaftGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" style={{stopColor:'#c0c0c0', stopOpacity:1}} />
                        <stop offset="100%" style={{stopColor:'#808080', stopOpacity:1}} />
                      </linearGradient>
                    </defs>
                    {/* Pin head */}
                    <circle cx="12" cy="8" r="6" fill="url(#pinGradient)" />
                    <circle cx="10" cy="6" r="1.5" fill="#ffffff" opacity="0.8" />
                    {/* Pin shaft */}
                    <rect x="11" y="14" width="2" height="8" fill="url(#shaftGradient)" rx="1" />
                    <rect x="11.2" y="14" width="1.6" height="8" fill="#ffffff" opacity="0.3" />
                  </svg>
                  {isLocating ? (
                    "Locating…"
                  ) : (
                    <span className="text-left text-xs">
                      <div>Drop A Pin</div>
                      <div>on Google Maps</div>
                    </span>
                  )}
                </div>
              </button>
            </div>

            {geoError && (
              <div className="mt-2 text-sm text-red-700">{geoError}</div>
            )}

            {pricingError && (
              <div className="mt-3 p-3 rounded-lg bg-red-50 border border-red-200">
                <div className="text-sm font-semibold text-red-800 mb-1">Pricing Error</div>
                <div className="text-sm text-red-700">{pricingError}</div>
              </div>
            )}
          </>
        ) : (
          <div className="rounded-2xl border-2 border-[#1e1e4a] bg-white px-6 py-4">
            <div className="text-sm font-semibold text-[#1e1e4a]/70 mb-1">Location</div>
            <div className="text-lg font-bold text-[#1e1e4a] break-words">{address}</div>
            <div className="mt-3">
              <button type="button" onClick={resetPickup} className="text-sm font-semibold underline underline-offset-2 text-[#1e1e4a]/80 hover:text-[#1e1e4a]">
                Edit location
              </button>
            </div>
          </div>
        )}
      </div>

      {/* DROPOFF SECTION (towing only) */}
      {isTowing && pickupConfirmed && (
        <div className="w-full max-w-2xl">
          {!dropoffConfirmed ? (
            <>
              <div className="mb-2 text-base font-semibold text-[#1e1e4a]">What is drop-off location</div>
              <input
                id="dropoffAddress"
                ref={inputRefDropoff}
                value={dropoff}
                onChange={(e) => setDropoff(e.target.value)}
                onFocus={() => initAutocompleteFor("dropoff")}
                onKeyDown={(e) => e.key === "Enter" && confirmDropoffIfManual()}
                type="text"
                placeholder="Enter drop-off address (street, city, ZIP)…"
                className="w-full h-16 rounded-2xl border-2 border-[#1e1e4a] bg-white px-6 text-xl focus:outline-none focus:ring-4 focus:ring-[#1e1e4a]/30 focus:border-[#1e1e4a] placeholder:text-[#1e1e4a]/40"
                autoComplete="off"
              />
              {distanceMilesRounded != null && (
                <div className="mt-2 text-sm text-[#1e1e4a]/70">
                  Estimated distance (rounded): <b>{distanceMilesRounded}</b> mi
                </div>
              )}
              <div className="mt-3">
                <button
                  type="button"
                  onClick={confirmDropoffIfManual}
                  className="rounded-xl px-5 py-3 font-semibold shadow-md border border-[#1e1e4a]/30 bg-white hover:bg-[#ffba42]/20 transition"
                >
                  Confirm drop-off
                </button>
              </div>
            </>
          ) : (
            <div className="rounded-2xl border-2 border-[#1e1e4a] bg-white px-6 py-4">
              <div className="text-sm font-semibold text-[#1e1e4a]/70 mb-1">Drop-off</div>
              <div className="text-lg font-bold text-[#1e1e4a] break-words">{dropoff}</div>
              {distanceMilesRounded != null && (
                <div className="mt-1 text-xs text-[#1e1e4a]/60">Estimated distance (rounded): {distanceMilesRounded} mi</div>
              )}
              <div className="mt-3">
                <button type="button" onClick={resetDropoff} className="text-sm font-semibold underline underline-offset-2 text-[#1e1e4a]/80 hover:text-[#1e1e4a]">
                  Edit drop-off
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* VEHICLE INFO */}
      <div className="w-full max-w-2xl grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="flex flex-col gap-1">
          <label htmlFor="year" className="text-sm font-semibold text-[#1e1e4a]">
            Year <span className="text-xs text-red-600">*</span>
          </label>
          <select
            id="year"
            value={year}
            onChange={(e) => setYear(e.target.value)}
            className="h-12 rounded-xl border-2 border-[#1e1e4a] bg-white px-3 text-base focus:outline-none focus:ring-4 focus:ring-[#1e1e4a]/30 focus:border-[#1e1e4a]"
          >
            <option value="">Select year</option>
            {YEARS.map((y) => (
              <option key={y} value={String(y)}>{y}</option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-1">
          <label htmlFor="make" className="text-sm font-semibold text-[#1e1e4a]">
            Make <span className="text-xs text-red-600">*</span>
          </label>
          <select
            id="make"
            value={isCustomMake ? "Other" : make}
            onChange={(e) => {
              const val = e.target.value;
              if (val === "Other") {
                setIsCustomMake(true);
                setMake("");
                setCustomMake("");
              } else {
                setIsCustomMake(false);
                setMake(val);
                setCustomMake("");
              }
            }}
            className="h-12 rounded-xl border-2 border-[#1e1e4a] bg-white px-3 text-base focus:outline-none focus:ring-4 focus:ring-[#1e1e4a]/30 focus:border-[#1e1e4a]"
          >
            <option value="">Select make</option>
            {MAKES.map((m) => (
              <option key={m} value={m}>{m}</option>
            ))}
            <option value="Other">Other (type your own)</option>
          </select>
        </div>

        {/* Custom Make Input - shown when "Other" is selected */}
        {isCustomMake && (
          <div className="flex flex-col gap-1 sm:col-span-2">
            <label htmlFor="customMake" className="text-sm font-semibold text-[#1e1e4a]">
              Enter your vehicle make
            </label>
            <input
              id="customMake"
              type="text"
              value={customMake}
              onChange={(e) => {
                const val = e.target.value;
                setCustomMake(val);
                setMake(val);
              }}
              placeholder="e.g., Maserati, Bentley, McLaren..."
              className="h-12 rounded-xl border-2 border-[#1e1e4a] bg-white px-4 text-base focus:outline-none focus:ring-4 focus:ring-[#1e1e4a]/30 focus:border-[#1e1e4a] placeholder:text-[#1e1e4a]/40"
              autoFocus
            />
          </div>
        )}

        <div className="flex flex-col gap-1">
          <label htmlFor="model" className="text-sm font-semibold text-[#1e1e4a]">
            Model <span className="text-xs text-red-600">*</span>
          </label>
          <select
            id="model"
            value={isCustomModel ? "Other" : model}
            onChange={(e) => {
              const val = e.target.value;
              if (val === "Other") {
                setIsCustomModel(true);
                setModel("");
                setCustomModel("");
              } else {
                setIsCustomModel(false);
                setModel(val);
                setCustomModel("");
              }
            }}
            disabled={!make.trim()}
            className={`h-12 rounded-xl border-2 border-[#1e1e4a] bg-white px-3 text-base focus:outline-none focus:ring-4 focus:ring-[#1e1e4a]/30 focus:border-[#1e1e4a] ${!make.trim() ? "opacity-60 cursor-not-allowed" : ""}`}
          >
            <option value="">{!make.trim() ? "Select make first" : "Select model"}</option>
            {modelsForMake.map((md) => (
              <option key={md} value={md}>{md}</option>
            ))}
            <option value="Other">Other (type your own)</option>
          </select>
        </div>

        {/* Custom Model Input - shown when "Other" is selected */}
        {isCustomModel && (
          <div className="flex flex-col gap-1 sm:col-span-2">
            <label htmlFor="customModel" className="text-sm font-semibold text-[#1e1e4a]">
              Enter your vehicle model
            </label>
            <input
              id="customModel"
              type="text"
              value={customModel}
              onChange={(e) => {
                const val = e.target.value;
                setCustomModel(val);
                setModel(val);
              }}
              placeholder="e.g., Granturismo, Continental GT, 720S..."
              className="h-12 rounded-xl border-2 border-[#1e1e4a] bg-white px-4 text-base focus:outline-none focus:ring-4 focus:ring-[#1e1e4a]/30 focus:border-[#1e1e4a] placeholder:text-[#1e1e4a]/40"
              autoFocus
            />
          </div>
        )}

        <div className="flex flex-col gap-1">
          <label htmlFor="color" className="text-sm font-semibold text-[#1e1e4a]">
            Color <span className="text-xs text-[#1e1e4a]/60">(optional)</span>
          </label>
          <select
            id="color"
            value={color}
            onChange={(e) => setColor(e.target.value)}
            className="h-12 rounded-xl border-2 border-[#1e1e4a] bg-white px-3 text-base focus:outline-none focus:ring-4 focus:ring-[#1e1e4a]/30 focus:border-[#1e1e4a]"
          >
            <option value="">Select color or skip</option>
            <option value="Skip">Skip</option>
            {COLORS.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}
