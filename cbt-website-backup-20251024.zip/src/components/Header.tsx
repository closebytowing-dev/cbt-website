"use client";
import ServicesMenu from "@/components/ServicesMenu";
import Link from "next/link";
import Image from "next/image";

export default function Header() {
  return (
    <header className="sticky top-0 z-50 w-full">
      {/* Top dark bar (reduced height ~40%) */}
      <div className="bg-[#1e1e4a] text-white">
        <div className="mx-auto max-w-[1800px] px-6 h-[4.5rem] flex items-center justify-between sm:justify-between">
          {/* Left: logo + brand text */}
          <div className="flex items-center gap-6">
            <Image
              src="/_archive/CloseBy-Towing-Logo.webp"
              alt="CloseBy Towing logo"
              width={96}
              height={96}
              className="w-auto h-10 sm:h-13"
              priority
            />
            <Link
              href="/"
              className="leading-tight font-bold tracking-tight text-sm sm:text-[1.8rem]"
            >
              <div className="text-red-500">CloseBy</div>
              <div className="opacity-90 font-normal">Towing</div>
            </Link>
          </div>

          {/* Right: phone button (scaled down) */}
          <div className="flex items-center ml-auto">
            <a
              href="tel:+18589999293"
              aria-label="Call CloseBy Towing (858) 999-9293"
              className="inline-flex flex-col items-center gap-1 rounded-lg border border-white/0 bg-transparent px-3 py-1.5 text-white text-xl font-semibold leading-none hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/40 active:scale-95 transition whitespace-nowrap"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" aria-hidden>
                <path
                  d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6A19.79 19.79 0 012.08 4.18 2 2 0 014.06 2h3a2 2 0 012 1.72c.13.99.35 1.96.66 2.9a2 2 0 01-.45 2.11l-1.27 1.27a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.94.31 1.91.53 2.9.66A2 2 0 0122 16.92z"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <span className="text-base sm:text-2xl font-semibold">(858) 999-9293</span>
            </a>
          </div>
        </div>
      </div>

      {/* Subnav bar (reduced height) */}
      <div className="bg-white text-[#1e1e4a] border-t border-[#1e1e4a]/10">
        <div className="mx-auto max-w-[1800px] px-6 h-12 flex items-center justify-center">
          <nav className="flex items-center gap-4 sm:gap-10 text-[1.0rem] md:text-[1.0rem] font-semibold leading-none">
            <ServicesMenu />
            <Link href="/#reviews" className="hover:opacity-60">
              Reviews
            </Link>
            <Link href="/#area" className="hover:opacity-60">
              Service Area
            </Link>
            <Link href="/about" className="hover:opacity-60">
              About
            </Link>
            <Link href="/contact" className="hover:opacity-60">
              Contact
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
