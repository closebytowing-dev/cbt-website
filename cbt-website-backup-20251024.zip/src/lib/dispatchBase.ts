export const DISPATCH_BASE_ADDRESS = "10325 Caminito Cuervo, San Diego, CA 92108";
