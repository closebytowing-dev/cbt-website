// src/lib/firebaseAdmin.ts
import { getApps, initializeApp, App, cert } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";

// Initialize Firebase Admin with service account JSON
const serviceAccount = {
    "type": "service_account",
    "project_id": "closebydriverapp1",
    "private_key_id": "01e53239445708d38d2246562c8fd2630bdb22bc",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDwSuu328849ImY\nojHGC0N47BxqHZDgah6RnMO67uTxtxtT2LY0XmQ9+wTd7ZhC+SqEA+wWxu0brNFq\nM6U5jGup7l570W7+Ni7Wai2NVpHW4EuvgGLH4FKU08qh8ykSRLVDKQ5/nfrpCmzq\ntzBZz8ldJW+Hrrj33NEm0i1grisK2PpuC0r57P5uA1s3Xv6EqiW59Wn/um3fUuTH\npY8W96klnQOIR9qg8AoQf6Aihugt+O0Ycd6fceZufZeliWKwu591h7NvYIX30d7L\n67i8El1J4D8PtXf8e4B1EU90/Qp72vYtFj/2YsQpR/IQ1LK3Q4RgpoOzmKLU6L2C\n5ZzTbBQ3AgMBAAECggEAd5KQobk78Pee0NlFM2u/c5jqutNjmIi2FXeQ3qCqRK39\nZ0fbw0uFTmJvFZB5yDn9MhxRizQKIU9qFhMFERITMUhws+SP+ugzfnbvm/mMMQUE\nJJ0aiqPR9EU//D7oHTMbkAQKNu8CQJzzfgkSgl6nsTZDvZzwZkb3vP2xnv6MZKSF\nenwIO1Q/eRjwoSDQzKwXB/+1qgST8CWSpTmJLxjE+nf6NdZR/6uQoYaIpFJXtBb0\n2MaYK7+IGWX7zCQeBNwQPJbkrN6jRvK7/kNQ0SOS9OKC3PpWD29+VKboPkk/Kb4Y\nDVowZay7zlx7zR+QXNU2klH5c8rVCpKy4hxCfAgMIQKBgQD8A0zCVW8eNjuGEsbN\nm/ZlT/nn8tZBuC4gHJux1aa4fx+YY9zXT/kRb4uapb3Gcf+3C0v7A7DMO1hZokI3\n2MvQTdnjK+kSCjBq4AGnGQwfopGXraDPWvBdtCQnqL5ipBPGx2+Kvbogn5xDQnHA\npN2m3W262bzGnwHNqNeQyfmU+wKBgQD0GCbaWVlWFLxLoNzAnN2L8duf3cZDyoDX\nTCXajMD5Cj0TXc/mmfzXLgGZs7Yafki1EHsRhwhxc5+o0TJNF7liohzE9iqd/bkK\nycncOQRDDPedz2+JT9Rwj3ZlRMaSl+bSXWAjt5kVnoSCvXeYRCdahIFBoYairPiS\nbpTHDMmA9QKBgGiumjjzMhgToQAdVpVb3qrQ4NcXiSZ9cjOGjqn9PKbQr3gmqzqJ\nDsXOVugjRsRi4DzRpXscWllLoXSCMQ1vsaHSZNq3h7Ylo10Rtb4Kan3Nkrq1teHM\nPaI+zPHoZ0UkMM7WUyAHlYQtqMRLmmLSWPwSaJ1ACulabW5XX0vWiiT3AoGAFQoz\n5yRGeA4HgPlXrd6XliV9ydTi7xr4ahZtON5jD9RbGV0/u1/QlHepuabs7nGuMLU/\n9m3OQ4E05OdLT6vY1fClTDDv0Xh6R7zHAo2DmYf3nAmyUoKoDB/Bk88O0rn3MnDM\nBaggsOVeBKryMRTG052SSqbypPkF4BFaD6JBiDUCgYA1H0eZMzjeOOayBQtr69Lx\n/DsdPp132x4vopJCh5p/NmAftsmwcBo6TubaVUHBS2ebRfIEF2yFJD+FLW81uJE7\nho0FU8lBmcgCPUTG3f4bbklVkRWT4RmhsEYOPuk2wxHpEYkt7quki7IPuTsc7PQP\nfcqQAZrn4cas4Pk/XJpNLw==\n-----END PRIVATE KEY-----\n",
    "client_email": "firebase-adminsdk-fbsvc@closebydriverapp1.iam.gserviceaccount.com",
    "client_id": "115162403838790604096",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40closebydriverapp1.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
};

const app: App = getApps()[0] || initializeApp({
    credential: cert(serviceAccount as Record<string, string>),
    projectId: "closebydriverapp1"
});

export const adminDb = getFirestore(app);
